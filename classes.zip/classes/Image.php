<?php
/**
 * Table Definition for image
 */
require_once INSTALLDIR.'/classes/Memcached_DataObject.php';

class Image extends Memcached_DataObject 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    public $__table = 'image';                           // table name
    public $id;                              // int(20)  not_null primary_key unsigned auto_increment
    public $portfolio_id;                    // int(11)  not_null
    public $original;                        // int(1)  unsigned
    public $width;                           // int(11)  not_null unsigned
    public $height;                          // int(11)  not_null unsigned
    public $mediatype;                       // string(32)  not_null binary
    public $filename;                        // string(255)  binary
    public $url;                             // string(255)  unique_key binary
    public $title;                           // string(255)  binary
    public $score;                           // int(11)  
    public $created;                         // datetime(19)  not_null binary
    public $modified;                        // timestamp(19)  not_null unsigned zerofill binary timestamp

    /* Static get */
    function staticGet($k,$v=NULL) { return Memcached_DataObject::staticGet('Image',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE


}
