<?php
/**
 * Table Definition for portfolio
 */
require_once INSTALLDIR.'/classes/Memcached_DataObject.php';

class DataObjects_Portfolio extends Memcached_DataObject 
{
    ###START_AUTOCODE
    /* the code below is auto generated do not remove the above tag */

    public $__table = 'portfolio';                       // table name
    public $id;                              // int(20)  not_null primary_key unsigned
    public $name;                            // string(128)  not_null
    public $owner;                           // int(64)  not_null
    public $catalog;                         // string(255)  not_null binary
    public $coverpic;                        // string(255)  
    public $description;                     // string(255)  
    public $created;                         // datetime(19)  not_null binary
    public $modified;                        // timestamp(19)  not_null unsigned zerofill binary timestamp

    /* Static get */
    function staticGet($k,$v=NULL) { return Memcached_DataObject::staticGet('Portfolio',$k,$v); }

    /* the code above is auto generated do not remove the tag below */
    ###END_AUTOCODE
    
    static function addPortfolio($fields) {

        extract($fields);
        
    	$portfolio = new Portfolio();
        $result = $portfolio->insert();

        if (!$result) {
            common_log_db_error($user, 'INSERT', __FILE__);
            return false;
        }
        
    }
}
